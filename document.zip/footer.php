<footer class="bg-gradient-to-r from-blue-700 to-purple-700 text-white text-center py-3 mt-10 shadow-inner text-xs md:text-base">
        <div class="flex flex-col items-center">
            <span class="text-base md:text-lg">© <?=date('Y')?> <?php echo htmlspecialchars($pageConfig['nameschool']); ?> | <?php echo htmlspecialchars($pageConfig['footerCredit']); ?> 🚀</span>
            <span class="mt-1">ติดต่อผู้ดูแลระบบ: line:tiwa.rpz</span>
        </div>
    </footer>